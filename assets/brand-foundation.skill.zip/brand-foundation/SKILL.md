---
name: brand-foundation
description: Interview a user to build a brand's foundational strategy document (Brand Overview, Audience, Values, Personality, Voice and Tone, Messaging, Visual Identity, Guardrails, AI Usage Notes) and output it in the exact structure of references/buildbrand.md. Use this whenever the user wants to define, document, or formalize a brand — brand strategy, brand guidelines, brand bible, brand voice/tone doc, positioning doc, or a "brand.md" / "AI brand guide" that other AI tools can reference. Trigger on requests like "help me define my brand", "build a brand strategy doc", "create brand guidelines", "write our brand voice and tone", or "I need a foundational brand document" — even if the user only mentions one section (e.g. "help me nail down our voice and tone") rather than the whole document, since that section still needs to be built with this same rigorous, no-placeholders interview process.
---

# Brand Foundation

Guides a user through defining a brand from first principles via a
structured, section-by-section interview, then outputs a complete
foundational brand document. The output format is defined by
`references/buildbrand.md` — read it before writing the final document
so the headings, order, and YAML frontmatter match exactly.

## Core principles

- **Mine existing material before interviewing.** If the user supplies
  a brief, website copy, pitch deck, or old guidelines, extract every
  answer you can from it first, recap the extracted answers section by
  section for confirmation, and interview only for the gaps. Re-asking
  what the user already wrote down erodes trust in the process.
- **One section at a time, in this exact order:** Brand Overview,
  Audience, Values, Personality, Voice and Tone, Messaging, Visual
  Identity, Guardrails, AI Usage Notes.
- **One focused question (or a small tight batch of directly related
  questions) at a time within a section.** Never dump a whole
  section's worth of questions on the user at once.
- **Push back on generic answers.** If an answer could paste onto any
  other brand in the category unchanged ("we want to feel premium and
  trustworthy," "quality," "innovation," "friendly and professional"),
  ask a follow-up that forces specificity before moving on. Good
  techniques: ask for the real decision or behavior a claim would
  drive; offer contrasting pairs and ask the user to pick a side;
  ask what a competitor would say instead.
- **Never invent brand truth on the user's behalf.** If the user is
  unsure, help them think it through with contrasting examples ("closer
  to A or closer to B?"), but the final call is always theirs. Do not
  write values, personality traits, or visual direction the user
  hasn't actually confirmed.
- **No placeholders in the final document.** Do not proceed to
  Guardrails until Brand Overview, Audience, Values, Personality,
  Voice and Tone, Messaging, and Visual Identity are all filled with
  real, specific content.
- **Guardrails are derived, not invented.** When you reach Guardrails,
  generate Must-do / Must-not-do / Coherence checks strictly from what
  was already defined in earlier sections — introduce no new brand
  attributes at this stage. Confirm the derived guardrails with the
  user before finalizing. If something earlier is too vague to derive
  a rule from, flag it and ask the user to go back and clarify that
  section rather than guessing.
- **The final document is the deliverable.** Once every section is
  complete, produce the full document as a file matching the exact
  structure, headings, and YAML frontmatter of
  `references/buildbrand.md` — no commentary before or after.

## Workflow

1. Read `references/buildbrand.md` to confirm the exact target
   structure before starting.
2. Start with Brand Overview (see prompts below). Work through each
   section in order, one question/tight batch at a time, pushing for
   specificity per the core principles above.
3. After each section is answered with real content, briefly recap it
   back to the user in the section's output structure (shown below) so
   they can correct anything before you move on — this can be shown
   inline in chat, it doesn't need to be a file yet.
4. When all sections through Visual Identity are complete, derive and
   confirm Guardrails.
5. Write "AI Usage Notes" — a short section on how an AI assistant
   should use this document (e.g. treat it as ground truth for
   tone/voice, defer to the human on anything not covered, flag
   outputs that conflict with Guardrails rather than silently
   softening them). Confirm with the user or ask if they want to add
   anything specific (e.g. tools/channels where this doc will be fed
   to an AI).
6. Assemble the full document using `references/buildbrand.md` as the
   exact template (fill in the YAML frontmatter: brand_name, version,
   last_updated, status), and save it as a markdown file (e.g.
   `<brand-name>-brand-foundation.md`) in the outputs directory.
   Present the file to the user with no extra commentary — the
   document is the deliverable.

## Section-by-section interview guide

### 1. Brand Overview

Ask, one at a time:
1. What does this brand actually do, and what category does it belong
   to? Push past a feature list — get the one-paragraph version a
   stranger would understand in five seconds.
2. Why does this need to exist, beyond making money? If the answer is
   generic ("we saw a gap in the market"), ask what personally drove
   them to build this instead of something else.
3. What does this brand actively refuse to become? Push for 2–4 real
   boundaries — a boundary that would never tempt them isn't a real
   boundary.
4. If you had to compress all of the above into one sentence that
   captures the essence of the brand, what would it be?

Output structure:
```
## What the brand is
[paragraph]

## Why the brand exists
[paragraph]

## What the brand is not
- 
- 
- 

## Brand Truth
[one sentence]
```

### 2. Audience

Use the completed Brand Overview as context. Ask, one at a time:
1. Who is this brand actually for, in practical terms — not a
   demographic label, but a specific kind of person in a specific
   situation. If they say "everyone," push back: who is it for first,
   before it's for everyone?
2. What are the top 2–3 needs this audience has that this brand
   addresses? Distinguish practical needs (what they need to get done)
   from emotional needs (how they need to feel while doing it).
3. How should this audience feel in the moment they encounter the
   brand — first five seconds, not after using the product for a year?

Output structure:
```
## Primary audience
[paragraph]

## Audience needs
- 
- 
- 

## Audience perception
[paragraph]
```

### 3. Values

Use Brand Overview and Audience as context. Ask about one value at a
time, not all four at once:
1. What are the 3–4 core values this brand operates by? Push for
   values that would actually change a decision if violated — not
   values every competitor would also claim ("quality," "innovation").
2. For each value, what does it actually look like in a real decision
   or behavior? If the user can't answer this, the value is too
   abstract — help them narrow it until it's actionable.

Output structure:
```
## Core values
1. 
2. 
3. 
4. 

## What each value means in practice
- [Value 1]: [behavior or decision it should drive]
- [Value 2]: [behavior or decision it should drive]
- [Value 3]: [behavior or decision it should drive]
```

### 4. Personality

Use Brand Overview, Audience, and Values as context. Ask:
1. If this brand were a person, what 3–5 traits would define their
   character? Push past a generic pair (e.g. "friendly and
   professional" — nearly every brand says this).
2. Give three contrasting pairs (e.g. "playful vs. serious," "formal
   vs. casual," "reserved vs. expressive") and ask the user to pick a
   side for each, or a point between them.
3. How does the brand sound? How does it behave? What does it actively
   avoid sounding like — a competitor, a cliché, or a tone that would
   betray the values already defined?

Output structure:
```
## Brand personality
[3–5 traits]

## Personality in practice
- The brand sounds like: 
- The brand behaves like: 
- The brand avoids sounding like: 
```

### 5. Voice and Tone

Use Personality as context. Make sure the user understands that voice
is constant while tone shifts by context before they answer. Ask:
1. What are 2–3 voice principles that hold true everywhere this brand
   speaks, regardless of context? (e.g. "always explain the why, never
   just the what")
2. How should tone shift across: homepage, social media, product/UI
   copy, and support/FAQ? Ask about each context separately — a brand
   that's playful on social media is often not playful in an error
   message, and that's fine, but it should be a decision, not an
   accident.
3. Give 3 pairs of "we say / we never say" — real phrases or phrase
   patterns, not abstractions. If the user gives an abstraction ("we're
   never corporate"), ask them to turn it into an actual sentence a
   competitor might write that this brand never would.

Output structure:
```
## Voice principles
1. 
2. 
3. 

## Tone by context
- Homepage: 
- Social media: 
- Product / UI: 
- Support / FAQ: 

## We say / We never say
| We say | We never say |
|---|---|
|  |  |
|  |  |
|  |  |
```

### 6. Messaging

Use Brand Overview, Audience, and Values as context. Ask:
1. What is the single core message this brand needs every audience
   member to walk away with, even if they forget everything else?
2. What are 2–3 supporting messages that reinforce the core message
   from different angles (e.g. one about the problem, one about the
   method, one about the outcome)?
3. What are the proof points — real, specific evidence (numbers,
   credentials, results, mechanisms) that back up the core message?
   Push back on proof points that are just restated claims rather than
   actual evidence.

Output structure:
```
## Core message
[sentence]

## Supporting messages
- 
- 
- 

## Key proof points
- 
- 
- 
```

### 7. Visual Identity

Use Personality, Values, and Voice and Tone as context — visual
choices should follow from these, not be picked independently. Ask:
1. In a sentence or two, what visual world should this brand live in?
   Reference existing brands, spaces, or aesthetics only as anchors —
   then ask what's different about this brand's version of that world.
2. For each palette role (primary, secondary, accent, neutral), what
   color and what is it used for? If the user only has a vibe ("cool
   colors"), connect it back to the personality traits already
   defined — which trait does this color serve?
3. What fonts for headline, body, and (if relevant) code/mono? Ask
   whether the personality is closer to structured/technical or
   warm/human, and let that drive the recommendation rather than
   picking a trendy font first.
4. What are 2–3 concrete visual rules (e.g. minimum contrast, spacing
   ratios, logo clear space)?
5. Give one real Do and one real Don't — specific enough that someone
   could look at two versions of a graphic and know which one violates
   the rule.

Output structure:
```
## Visual direction
[paragraph]

## Color palette
- Primary: [color name] — [hex] — [usage]
- Secondary: [color name] — [hex] — [usage]
- Accent: [color name] — [hex] — [usage]
- Neutral: [color name] — [hex] — [usage]

## Typography
- Headline font: 
- Body font: 
- Optional code / mono font: 

## Visual rules
- 
- 
- 

## Visual do / don't
- Do: 
- Do: 
- Don't: 
- Don't: 
```

### 8. Guardrails (derived, not asked)

Only do this once Brand Overview, Audience, Values, Personality, Voice
and Tone, Messaging, and Visual Identity are all filled in with real
content. Using only what's defined in those sections — introduce no
new brand attributes, values, or visual choices — generate:

- **Must-do:** 3–5 non-negotiable rules that follow directly from the
  values, personality, and visual direction already defined.
- **Must-not-do:** 3–5 explicit things this brand must avoid, derived
  from "What the brand is not" and any tension points in the
  personality, tone, or visual direction (e.g. a "warm" brand must not
  ship cold, clinical color combinations).
- **Coherence checks:** a short checklist that someone — or an AI —
  can run against any new output to verify it's on-brand.

Rules for this section:
- Every guardrail must be specific and testable. Avoid vague
  statements like "be authentic" — say what that means in a visible,
  checkable way: exact color usage, tone limits, claims allowed vs.
  not allowed, spacing, contrast, etc.
- **Write rules about meaning, not bare counts.** "Max 3 colors" is a
  diet — it dies on the next redesign. "Every color must read as warm"
  is a rule about meaning — it survives anything. When a count or
  limit genuinely matters, state the reason it protects, so the rule
  can be re-derived when the count changes.
- Keep each Must-do / Must-not-do to one short, direct sentence.
- Do not restate the Values section verbatim — Guardrails are the
  operational rules values produce, not the values themselves.
- If something in the earlier sections is too vague to derive a rule
  from, flag it and ask the user to clarify that section instead of
  guessing.

Present the derived guardrails to the user and confirm before
finalizing.

Output structure:
```
## Must-do
- 
- 
- 

## Must-not-do
- 
- 
- 

## Coherence checks
- Does this feel aligned with the brand truth?
- Does this match the values?
- Does this sound / look like the right personality?
- Does this reduce friction for the audience?
```

## Contradiction audit (before assembly)

Sections can each pass alone and still break combined. Before
assembling the final document, run one integration pass across ALL
sections and list every place where two of them disagree — for
example: personality says "warm" but the palette is cold and clinical;
voice says "plain language" but the messaging leans on jargon; the
audience needs reassurance but the tone rules read as brash. Present
the contradictions (or state explicitly that none were found) and let
the user resolve each one before you assemble. Do not silently
harmonize conflicts yourself — a contradiction is the user's decision
surfacing, not a writing problem.

## Final assembly

Once Guardrails are confirmed and AI Usage Notes are written, produce
the complete document following `references/buildbrand.md` exactly —
same section order, same headings, same YAML frontmatter fields
(`brand_name`, `version`, `last_updated`, `status`). Save it as a
markdown file and present it to the user. No commentary before or
after the document — it is the deliverable.
