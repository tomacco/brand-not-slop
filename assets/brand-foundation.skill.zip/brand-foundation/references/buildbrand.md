---
brand_name: 
version: 1.0
last_updated: 
status: draft
---

# Brand Overview

## What the brand is
[paragraph]

## Why the brand exists
[paragraph]

## What the brand is not
- 
- 
- 

## Brand Truth
[one sentence]

# Audience

## Primary audience
[paragraph]

## Audience needs
- 
- 
- 

## Audience perception
[paragraph]

# Values

## Core values
1. 
2. 
3. 
4. 

## What each value means in practice
- [Value 1]: [behavior or decision it should drive]
- [Value 2]: [behavior or decision it should drive]
- [Value 3]: [behavior or decision it should drive]

# Personality

## Brand personality
[3–5 traits]

## Personality in practice
- The brand sounds like: 
- The brand behaves like: 
- The brand avoids sounding like: 

# Voice and Tone

## Voice principles
1. 
2. 
3. 

## Tone by context
- Homepage: 
- Social media: 
- Product / UI: 
- Support / FAQ: 

## We say / We never say
| We say | We never say |
|---|---|
|  |  |
|  |  |
|  |  |

# Messaging

## Core message
[sentence]

## Supporting messages
- 
- 
- 

## Key proof points
- 
- 
- 

# Visual Identity

## Visual direction
[paragraph]

## Color palette
- Primary: [color name] — [hex] — [usage]
- Secondary: [color name] — [hex] — [usage]
- Accent: [color name] — [hex] — [usage]
- Neutral: [color name] — [hex] — [usage]

## Typography
- Headline font: 
- Body font: 
- Optional code / mono font: 

## Visual rules
- 
- 
- 

## Visual do / don't
- Do: 
- Do: 
- Don't: 
- Don't: 

# Guardrails

## Must-do
- 
- 
- 

## Must-not-do
- 
- 
- 

## Coherence checks
- Does this feel aligned with the brand truth?
- Does this match the values?
- Does this sound / look like the right personality?
- Does this reduce friction for the audience?

# AI Usage Notes
[Notes on how an AI assistant should use this document — e.g. treat it as
ground truth for tone/voice when generating brand copy, defer to the
human on anything not explicitly covered here, flag outputs that
conflict with the Guardrails section rather than silently softening
them.]
